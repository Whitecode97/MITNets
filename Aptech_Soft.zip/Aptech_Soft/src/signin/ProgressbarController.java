/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package signin;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.animation.PauseTransition;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ProgressIndicator;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

/**
 * FXML Controller class
 *
 * @author user
 */
public class ProgressbarController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
     @FXML
    private ProgressIndicator progress;

     
     @FXML
    private AnchorPane progressanchor;
    
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
         PauseTransition transition = new PauseTransition();
        transition.setDuration(Duration.seconds(10));
        transition.setOnFinished(event -> {
            try {
              
                FXMLLoader loader = new FXMLLoader();
                loader.setLocation(getClass().getResource("/signin/Success.fxml"));
                AnchorPane ap = loader.load();
                Stage stage = new Stage();
                stage.setScene(new Scene(ap));
                  stage.initStyle(StageStyle.UNDECORATED);
                stage.show();
                  Stage s  = (Stage)progressanchor.getScene().getWindow();
                s.close();
            } catch (IOException ex) {
                Logger.getLogger(LoadingController.class.getName()).log(Level.SEVERE, null, ex);
            }
            });
        transition .play();

    }    
    
}
