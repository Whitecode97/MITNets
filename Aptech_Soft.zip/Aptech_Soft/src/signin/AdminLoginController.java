/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package signin;

import com.jfoenix.controls.JFXPasswordField;
import com.jfoenix.controls.JFXTextField;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.image.Image;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;
import javafx.stage.StageStyle;

/**
 * FXML Controller class
 *
 * @author user
 */
public class AdminLoginController implements Initializable {

    /**
     * Initializes the controller class.
     */
    String user ="admin";
    
    String pass = "break";
    
    @FXML
    private AnchorPane adminloginanchor;
    
    @FXML
    private JFXTextField username;

    @FXML
    private JFXPasswordField password;

    @FXML
    void adminlogin(ActionEvent event) throws IOException {
        String name = username.getText();
        String passw = password.getText();
        if(name.isEmpty()|| pass.isEmpty()){
                Alert a = new Alert(AlertType.ERROR);
                a.setHeaderText(null);
                a.setContentText("Please fill in a complete information. Thanks");
                a.initStyle(StageStyle.UNDECORATED);
                a.showAndWait();
        }else if((!name.equalsIgnoreCase(user)) || ((!pass.equalsIgnoreCase(pass)))){
            Alert a = new Alert(AlertType.ERROR);
            a.setHeaderText(null);
            a.setContentText("Your input is incorrect");
            a.initStyle(StageStyle.UNDECORATED);
            a.showAndWait();
            username.clear();
            password.clear();
        }
        else if(name.equals(user)&& passw.equals(pass)){
            
        FXMLLoader loader = new FXMLLoader();
        loader.setLocation(getClass().getResource("/signin/AdminControl.fxml"));
          AnchorPane ap = loader.load();
        Stage stage = new Stage();
        stage.setScene(new Scene(ap));
        stage.setTitle("Administration Control");
        stage.getIcons().add(new Image(getClass().getResourceAsStream("/img/2-2-education-picture.png")));
        stage.setResizable(false);
        stage.show();
        Stage s = (Stage) adminloginanchor.getScene().getWindow();
        s.close();
        }
        else{
            Alert a = new Alert(AlertType.ERROR);
            a.setHeaderText(null);
            a.setContentText("Invalid Username or Password");
            a.showAndWait();
        }
      

    }

    @FXML
    private void cancel(ActionEvent event) {
        System.exit(0);
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }

}
